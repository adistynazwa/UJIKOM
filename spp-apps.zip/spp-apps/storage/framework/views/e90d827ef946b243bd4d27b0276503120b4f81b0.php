<?php $__env->startSection('page-name','Siswa'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('page-name'); ?></h3>
                </div>
                <div class="card-body">
                    <p><b>Kelas</b> : <?php echo e($siswa->kelas->nama_kelas); ?> </p>
                    <p>
                        <b>Nama</b> : <?php echo e($siswa->nama); ?> 
                        
                    </p>
                    
                    <p><b>NISN</b> : <?php echo e($siswa->nisn); ?> </p>
                    <p><b>NIS</b> : <?php echo e($siswa->nis); ?> </p>
                    <p><b>No. Telepon</b> : <?php echo e($siswa->telp_wali); ?> </p>
                    <p><b>Alamat</b> : <?php echo e($siswa->alamat); ?> </p>
                </div>
            </div>
        </div>
        
        <div class="col-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Tagihan SPP</h3>
                    <?php if(!$siswa->is_yatim): ?>
                    <div class="card-options">
                        <input class="form-control mr-2" type="text" name="dates" style="max-width: 200px" id="daterange" value="<?php echo e(now()->subDay(7)->format('m-d-Y')." - ".now()->format('m-d-Y')); ?>">
                        <button id="btn-cetak-spp" class="btn btn-primary mr-1" value="<?php echo e($siswa->id); ?>">Cetak</button>
                        <button id="btn-export-spp" class="btn btn-primary" value="<?php echo e($siswa->id); ?>">Export</button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if($siswa->is_yatim): ?>
                        <b>Siswa/Siswi Yatim biaya Gratis</b>
                    <?php else: ?>
                    <table class="table card-table table-hover table-vcenter text-wrap">
                        <tr>
                            <th>Nama Tagihan</th>
                            <th>Total</th>
                            <th>Lunas</th>
                            <th>Tanggal</th>
                            <th>Keterangan</th>
                        </tr> 
                        <?php $__currentLoopData = $tagihan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($siswa->nama); ?></td>
                            <td><?php echo e($item['total']); ?></td>
                            <td>
                                <?php if($item['is_lunas']): ?>
                                    <span class="tag tag-green">Lunas</span>
                                <?php else: ?>
                                    <span class="tag tag-purple">Belum</span>
                                <?php endif; ?> 
                            </td>
                            <td><?php echo e($item['created_at']); ?></td>
                            <td><?php echo e($item['keterangan']); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/daterangepicker.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    require(['jquery', 'moment','daterangepicker'], function ($, moment, daterangepicker) {
        $(document).ready(function () {
            $('input[name="dates"]').daterangepicker();
        });
        $('#btn-cetak-spp').on('click', function(){
            //form print
            var form = document.createElement("form");
            form.setAttribute("style", "display: none");
            form.setAttribute("method", "post");
            form.setAttribute("action", "<?php echo e(route('spp.print')); ?>/" + this.value);
            form.setAttribute("target", "_blank");
            
            var token = document.createElement("input");
            token.setAttribute("name", "_token");
            token.setAttribute("value", "<?php echo e(csrf_token()); ?>");
            
            var dateForm = document.createElement("input");
            dateForm.setAttribute("name", "dates");
            dateForm.setAttribute("value", $('#daterange').val());

            form.appendChild(token);
            form.appendChild(dateForm);
            document.body.appendChild(form);
            form.submit();

            console.log($('#daterange').val())
        })

        $('#btn-export-spp').on('click', function(){
            //form print
            var form = document.createElement("form");
            form.setAttribute("style", "display: none");
            form.setAttribute("method", "post");
            form.setAttribute("action", "<?php echo e(route('spp.export')); ?>/" + this.value);
            form.setAttribute("target", "_blank");
            
            var token = document.createElement("input");
            token.setAttribute("name", "_token");
            token.setAttribute("value", "<?php echo e(csrf_token()); ?>");
            
            var dateForm = document.createElement("input");
            dateForm.setAttribute("name", "dates");
            dateForm.setAttribute("value", $('#daterange').val());

            form.appendChild(token);
            form.appendChild(dateForm);
            document.body.appendChild(form);
            form.submit();

            console.log($('#daterange').val())
        })
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spp-paud\resources\views/siswa/show.blade.php ENDPATH**/ ?>