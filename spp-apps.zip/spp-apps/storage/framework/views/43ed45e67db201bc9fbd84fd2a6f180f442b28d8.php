<?php $__env->startSection('site-name','Sistem Informasi SPP'); ?>
<?php $__env->startSection('page-name', (isset($siswa) ? 'Ubah Siswa' : 'Siswa Baru')); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-8">
            <form action="<?php echo e((isset($siswa) ? route('siswa.update', $siswa->id) : route('siswa.create'))); ?>" method="post" class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $__env->yieldContent('page-name'); ?></h3>
                </div>
                <div class="card-body">
                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($error); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-12">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label class="form-label">Kelas</label>
                                <select id="select-beast" class="form-control custom-select" name="kelas_id">
                                    <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(isset($siswa) ? ($item->id == $siswa->kelas_id ? 'selected' : '') : ''); ?>><?php echo e($item->nama_kelas); ?></option>
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Nama</label>
                                <input type="text" class="form-control" name="nama" placeholder="Nama Lengkap" value="<?php echo e(isset($siswa) ? $siswa->nama : old('nama')); ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">NISN</label>
                                <input type="text" class="form-control" name="nisn" placeholder="NISN" value="<?php echo e(isset($siswa) ? $siswa->nisn : old('nisn')); ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label">NIS</label>
                                <input type="text" class="form-control" name="nis" placeholder="NIS" value="<?php echo e(isset($siswa) ? $siswa->nis : old('nis')); ?>">
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Jenis Kelamin</label>
                                <select id="select-beast" class="form-control custom-select" name="jenis_kelamin">
                                    <option value="L" <?php echo e(isset($siswa) ? ($siswa->jenis_kelamin == 'L' ? 'selected' : '') : ''); ?>>Laki - Laki</option>
                                    <option value="P" <?php echo e(isset($siswa) ? ($siswa->jenis_kelamin == 'P' ? 'selected' : '') : ''); ?>>Perempuan</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Alamat</label>
                                <textarea class="form-control" name="alamat"><?php echo e(isset($siswa) ? $siswa->alamat : old('alamat')); ?></textarea>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">No. Telepon</label>
                                <input type="text" class="form-control" name="telp_wali" placeholder="Nomor Telp. Lengkap" value="<?php echo e(isset($siswa) ? $siswa->telp_wali : old('telp_wali')); ?>">
                            
                            
                        </div>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <div class="d-flex">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-link">Batal</a>
                        <button type="submit" class="btn btn-primary ml-auto">Simpan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    require(['jquery', 'selectize','datepicker'], function ($, selectize) {
        $(document).ready(function () {

            $('.custom-select').selectize({});
            $('[data-toggle="datepicker"]').datepicker({
                format: 'yyyy-MM-dd'
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spp-paud\resources\views/siswa/form.blade.php ENDPATH**/ ?>